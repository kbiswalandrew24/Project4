package edu.heinz.ds.androidinterestingpicture;
/**Andrew Id: kbiswal
 * Name: Krishna Biswal*/
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


import java.util.List;


public class InterestingmeowFacts extends AppCompatActivity {

    InterestingmeowFacts me = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*
         * The click listener will need a reference to this object, so that upon successfully finding a picture from Flickr, it
         * can callback to this object with the resulting picture Bitmap.  The "this" of the OnClick will be the OnClickListener, not
         * this InterestingPicture.
         */
        final InterestingmeowFacts ma = this;

        /*
         * Find the "submit" button, and add a listener to it
         */
        Button submitButton = (Button)findViewById(R.id.submit);


        // Add a listener to the send button
        submitButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View viewParam) {
                if (isNetworkAvailable()) {
                String searchTerm = ((EditText)findViewById(R.id.searchTerm)).getText().toString();
                try {
                    int inputValue = Integer.parseInt(searchTerm);

                    if (inputValue >= 0 && inputValue <= 20) {
                        // Input is a valid integer and less than 20
                        GetFacts gp = new GetFacts();
                        gp.search(searchTerm, me, ma);
                    } else {
                        // Input is not less than 20
                        Toast.makeText(getApplicationContext(), "Please enter an integer less than 20", Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    // Input is not a valid integer
                    Toast.makeText(getApplicationContext(), "Please enter a valid integer", Toast.LENGTH_SHORT).show();
                }
                }else {
                    Toast.makeText(getApplicationContext(), "No internet connection available", Toast.LENGTH_SHORT).show();
                }
               }
        });
    }
    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager != null) {
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            return activeNetworkInfo != null && activeNetworkInfo.isConnected();
        }
        return false;
    }

    public void displayReady(List<MeowFact> meowFacts) {
        TextView factTextView = findViewById(R.id.factTextView);

        if (meowFacts != null && !meowFacts.isEmpty()) {
            StringBuilder stringBuilder = new StringBuilder();

            for (MeowFact meowFact : meowFacts) {
                // Append each fact to the StringBuilder
                stringBuilder.append(meowFact.getData()).append("\n");
            }

            // Set the text in the TextView
            factTextView.setText(stringBuilder.toString()+"\n\n\n");
        } else {
            // Handle the case where there are no facts
            factTextView.setText("No MeowFacts available.");
        }
    }
}
