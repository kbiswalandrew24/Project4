package edu.heinz.ds.androidinterestingpicture;
/**Andrew Id: kbiswal
 * Name: Krishna Biswal*/

public class MeowFact {
    private String data;

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
