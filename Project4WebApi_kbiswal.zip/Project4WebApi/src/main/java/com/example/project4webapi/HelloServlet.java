package com.example.project4webapi;
/**Andrew Id: kbiswal
 * Name: Krishna Biswal*/

import com.mongodb.client.*;
import com.mongodb.client.model.Sorts;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import java.io.PrintWriter;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.bson.Document;


@WebServlet(name = "helloServlet", value = "/meow-facts")
public class HelloServlet extends HttpServlet {
    private static final Logger LOGGER = LoggerFactory.getLogger(HelloServlet.class);
    private static final String uri = "mongodb://kbiswal:KIqxUrbt7sJGJeVG@ac-ydyz82n-shard-00-00.bzt9i0w.mongodb.net:27017,ac-ydyz82n-shard-00-01.bzt9i0w.mongodb.net:27017,ac-ydyz82n-shard-00-02.bzt9i0w.mongodb.net:27017/?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1";

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");

        String userAgent = request.getHeader("User-Agent");

        if (userAgent != null && userAgent.toLowerCase().contains("mobile")) {
            response.setContentType("application/json"); // Set content type to JSON for mobile clients
        }
        PrintWriter out = response.getWriter();



        try {
            String userInput = request.getParameter("userInput");

            // Log information for the mobile phone request
            LOGGER.info("Mobile phone request received - User Input: {}", userInput);


            // Log timestamp for when the request is received
            long requestTimestamp = System.currentTimeMillis();
            LOGGER.info("Request received at timestamp: {}", requestTimestamp);
            Random rand = new Random();
            int user_input = rand.nextInt(20);

            // Call the 3rd party API
            URL url = new URL("https://meowfacts.herokuapp.com/?count="+user_input);
            //+userInput
            String uri = "mongodb://kbiswal:KIqxUrbt7sJGJeVG@ac-ydyz82n-shard-00-00.bzt9i0w.mongodb.net:27017,ac-ydyz82n-shard-00-01.bzt9i0w.mongodb.net:27017,ac-ydyz82n-shard-00-02.bzt9i0w.mongodb.net:27017/?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1";
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");

            int responseCode = con.getResponseCode();
            // Log information about the request to the 3rd party API
            LOGGER.info("Request to 3rd party API - URL: {}, Response Code: {}", url, responseCode);


            if (responseCode == HttpURLConnection.HTTP_OK) {
                // Read the response
                BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String inputLine;
                StringBuilder responseBuilder = new StringBuilder();

                while ((inputLine = in.readLine()) != null) {
                    responseBuilder.append(inputLine);
                }

                in.close();

                JSONObject jsonResponse = new JSONObject(responseBuilder.toString());

                // Log information about the response from the 3rd party API
                LOGGER.info("Response from 3rd party API - Response Data: {}", jsonResponse);

                JSONArray dataArray = jsonResponse.getJSONArray("data");
                // Log information about the reply to the mobile phone
                LOGGER.info("Reply to mobile phone - Data sent: {}", dataArray);

                // Log timestamp for when the response is sent
                long responseTimestamp = System.currentTimeMillis();
                LOGGER.info("Response sent at timestamp: {}", responseTimestamp);

                //write to mongo db
                System.out.println("Mongodb code starts here ");

                // Write to MongoDB
                storeLogsInMongoDB(userInput, url, responseCode, jsonResponse, dataArray, requestTimestamp,
                        responseTimestamp);


                // Generate HTML response
                out.println("<html><body>");
                out.println("<h1>Meow Facts</h1>");
                out.println("<ul>");

                // Extract and print data
                for (int i = 0; i < dataArray.length(); i++) {
                    String fact = dataArray.getString(i);
                    out.println("<li>" + fact + "</li>");
                }

                // Display operations analytics
                displayOperationsAnalytics(out, dataArray);

                // Display formatted full logs
                displayFormattedLogs(out);

                out.println("</ul>");
                out.println("</body></html>");

                // Log the total processing time
                long processingTime = responseTimestamp - requestTimestamp;
                LOGGER.info("Total processing time: {} ms", processingTime);
            } else {
                LOGGER.error("Invalid data received from the third-party API");
                out.println("<html><body>");
                out.println("<h1>Invalid data received from the third-party API</h1>");
                out.println("</body></html>");
            }
        } catch (IOException e) {
            // Handle network failure
            LOGGER.error("Error occurred: Unable to reach the third-party API");
            out.println("<html><body>");
            out.println("<h1>Error occurred: Unable to reach the third-party API</h1>");
            out.println("</body></html>");
        } catch (Exception e) {
            // Print the error message to the console
            LOGGER.error("Error occurred: {}", e.getMessage(), e);
            e.printStackTrace();
            out.println("<html><body>");
            out.println("<h1>Error occurred: " + e.getMessage() + "</h1>");
            out.println("</body></html>");
        } finally {
            out.close();
        }
    }

    private void storeLogsInMongoDB(String userInput, URL url, int responseCode, JSONObject jsonResponse,
                                    JSONArray dataArray, long requestTimestamp, long responseTimestamp) {
        try (MongoClient mongoClient = MongoClients.create(uri)) {
            MongoDatabase database = mongoClient.getDatabase("mydb");
            MongoCollection<Document> logCollection = database.getCollection("logcollection");

            Document logDocument = new Document();
            logDocument.append("user_input", userInput)
                    .append("apiUrl", url.toString())
                    .append("responseCode", responseCode)
                    .append("responseData", jsonResponse.toString())
                    .append("dataArray", dataArray.toString())
                    .append("requestTimestamp", requestTimestamp)
                    .append("responseTimestamp", responseTimestamp);

            logCollection.insertOne(logDocument);
        } catch (Exception e) {
            LOGGER.error("Error occurred while storing logs in MongoDB: {}", e.getMessage(), e);
        }
    }
    private void displayOperationsAnalytics(PrintWriter out, JSONArray dataArray) {
        // Display operations analytics directly in the HTML response
        int factsOver10Words = 0;
        int factsAboutCatsEars = 0;
        int factsAboutCatsDiet = 0;

        for (int i = 0; i < dataArray.length(); i++) {
            String fact = dataArray.getString(i);

            // Count facts with more than 10 words
            if (fact.split("\\s+").length > 10) {
                factsOver10Words++;
            }

            // Count facts about cats' ears
            if (fact.toLowerCase().contains("ears")) {
                factsAboutCatsEars++;
            }

            // Count facts about cats' diet
            if (fact.toLowerCase().contains("diet")) {
                factsAboutCatsDiet++;
            }
        }

        // Display the analytics in an HTML table
        out.println("<h2>Operations Analytics</h2>");
        out.println("<table>");
        out.println("<tr><td>Facts over 10 words</td><td>" + factsOver10Words + "</td></tr>");
        out.println("<tr><td>Facts about cats' ears</td><td>" + factsAboutCatsEars + "</td></tr>");
        out.println("<tr><td>Facts about cats' diet</td><td>" + factsAboutCatsDiet + "</td></tr>");
        out.println("</table>");
    }

    private void displayFormattedLogs(PrintWriter out) {
        try (MongoClient mongoClient = MongoClients.create(uri)) {
            MongoDatabase database = mongoClient.getDatabase("mydb");
            MongoCollection<Document> logCollection = database.getCollection("logcollection");

            // Query all logs and sort them by timestamp (you can customize the query as needed)
            FindIterable<Document> logs = logCollection.find().sort(Sorts.ascending("requestTimestamp"));

            // Display logs in an HTML table
            out.println("<h2>Full Logs</h2>");
            out.println("<table border='1'>");
            out.println("<tr><th>User Input</th><th>API URL</th><th>Response Code</th><th>Response Data</th><th>Data Array</th><th>Request Timestamp</th><th>Response Timestamp</th></tr>");

            for (Document log : logs) {
                out.println("<tr>");
                out.println("<td>" + log.getString("user_input") + "</td>");
                out.println("<td>" + log.getString("apiUrl") + "</td>");
                out.println("<td>" + log.getInteger("responseCode") + "</td>");
                out.println("<td>" + log.getString("responseData") + "</td>");
                out.println("<td>" + log.getString("dataArray") + "</td>");
                out.println("<td>" + log.getLong("requestTimestamp") + "</td>");
                out.println("<td>" + log.getLong("responseTimestamp") + "</td>");
                out.println("</tr>");
            }

            out.println("</table>");
        } catch (Exception e) {
            LOGGER.error("Error occurred while retrieving logs from MongoDB: {}", e.getMessage(), e);
            out.println("<p>Error occurred while retrieving logs from MongoDB</p>");
        }
    }


}




