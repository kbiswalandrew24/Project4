package com.example.project4webapi;
/**Andrew Id: kbiswal
 * Name: Krishna Biswal*/

import java.util.List;

public class MeowFactList {
    private List<MeowFact> data;

    public List<MeowFact> getMeowFacts() {
        return data;
    }

    public void setMeowFacts(List<MeowFact> data) {
        this.data = data;
    }
}

